
function setup() {
  createCanvas(windiwWidth, windowHeight). position(0,0).style(´-index´,-1)
  createA("https://github.com/IsidoraRetamal", ("welcome"),"_blank");
  function setup() {
  createCanvas(400, 100);
  frameRate(2);
}

function draw() {
  background(random(0,255),random(0,255),random(0,255));
  text("welcome 🦁"), mouseX, mouseY);
}